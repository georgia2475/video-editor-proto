import {Input,MP4,BlobSource,VideoSampleSink,AudioSampleSink,Output,BufferTarget,Mp4OutputFormat,CanvasSource,AudioSampleSource,AudioSample,canEncodeAudio,canEncodeVideo} from 'mediabunny';
import {registerAacEncoder} from '@mediabunny/aac-encoder';
let running=false;let fallbackRegistered=false;let stopped=false;let output:any;let inputs:any[]=[];let mixers:AudioMixer[]=[];
const W=720,H=1280,FPS=30,SR=48000;
async function caps(){
 const video=await canEncodeVideo('avc',{width:W,height:H,bitrate:2000000,frameRate:FPS});
 let native=!fallbackRegistered && await canEncodeAudio('aac',{sampleRate:SR,numberOfChannels:2,bitrate:128000});
 if(!native&&!fallbackRegistered){registerAacEncoder();fallbackRegistered=true;}
 return {video,audio:await canEncodeAudio('aac',{sampleRate:SR,numberOfChannels:2,bitrate:128000}),aac:native?'native':'WASM fallback'};
}
function check(){if(stopped)throw Error('Export stopped. Your source is unchanged.');}
async function open(file:File){
 if(file.size>50*1024*1024)throw Error('Test limit: each file must be under 50 MB.');
 let i=new Input({source:new BlobSource(file),formats:[MP4]});inputs.push(i);
 let v=await i.getPrimaryVideoTrack(),a=await i.getPrimaryAudioTrack(),duration=await i.computeDuration();
 if(!v||v.codec!=='avc'||(a&&a.codec!=='aac'))throw Error('This test needs an H.264 MP4 with AAC audio (or no audio). HEVC/HDR/other formats are not supported yet.');
 if(v.codedWidth*v.codedHeight>1920*1080||duration>30||duration<=0)throw Error('Test input limit: 1080p and 30 seconds. Choose a shorter standard-quality clip.');
 const color=await v.getColorSpace(); if(color?.transfer==='pq'||color?.transfer==='hlg')throw Error('HDR is not supported in this test. Use an SDR clip.');
 if(!await v.canDecode()||(a&&!await a.canDecode()))throw Error('Your browser cannot decode this clip. Try the included demo.');
 return {input:i,v,a,duration};
}
// One sequential decoder iterator per source; retain only its current sample.
class AudioMixer {
 iterator:any; sample:any=null; planes:Float32Array[]=[];done=false;
 constructor(track:any,start:number,end:number){this.iterator=new AudioSampleSink(track).samples(start,end);mixers.push(this);}
 release(){this.sample?.close();this.sample=null;this.planes=[];}
 async next(){this.release();const r=await this.iterator.next();this.done=r.done;if(r.done)return;this.sample=r.value;
  if(this.sample.duration>1){this.release();throw Error('Unusually large decoded audio block. Choose another clip.');}
  for(let ch=0;ch<2;ch++){const plane=new Float32Array(this.sample.numberOfFrames);this.sample.copyTo(plane,{planeIndex:Math.min(ch,this.sample.numberOfChannels-1),format:'f32-planar'});this.planes.push(plane);}
 }
 async fill(sourceStart:number,n:number,gain:number,dst:Float32Array[]){
  const until=sourceStart+n/SR;
  while(!this.done){check();if(!this.sample)await this.next();if(this.done)return;const a=this.sample;
   if(a.timestamp>=until)return;
   if(a.timestamp+a.duration<=sourceStart){await this.next();continue;}
   const first=Math.max(0,Math.ceil((a.timestamp-sourceStart)*SR)),last=Math.min(n,Math.ceil((a.timestamp+a.duration-sourceStart)*SR));
   for(let ch=0;ch<2;ch++){const src=this.planes[ch],out=dst[ch];for(let k=first;k<last;k++){const pos=(sourceStart+k/SR-a.timestamp)*a.sampleRate,q=Math.floor(pos),f=pos-q;if(q>=0&&q<src.length)out[k]+=gain*(src[q]*(1-f)+src[Math.min(q+1,src.length-1)]*f);}}
   if(a.timestamp+a.duration<=until+1e-8)await this.next();else return;
  }
 }
 async close(){this.release();try{await this.iterator.return();}catch{}}
}
self.onmessage=async e=>{
 if(e.data.type==='stop'){stopped=true;return;}
 if(e.data.type==='caps'){try{self.postMessage({type:'caps',...await caps()});}catch(err){self.postMessage({type:'error',message:String(err)});}return;}
 if(e.data.type!=='export'||running)return;running=true;
 stopped=false; inputs=[];
 try{
  const c=await caps();if(!c.video||!c.audio)throw Error('This device cannot encode the required MP4. No video has been uploaded.');
  const {file,start,end,caption,volume,music}=e.data;const clip=await open(file);
  if(!Number.isFinite(start)||!Number.isFinite(end)||start<0||end>clip.duration+0.01||end-start<0.25||end-start>10.01)throw Error('Select between 0.25 and 10 seconds within the clip.');
  let musicInput:any,musicSink:any;
  if(music){if(music.size>20*1024*1024)throw Error('Music test limit: 20 MB.');musicInput=new Input({source:new BlobSource(music),formats:[MP4]});inputs.push(musicInput);const a=await musicInput.getPrimaryAudioTrack();if(!a||a.codec!=='aac'||!await a.canDecode())throw Error('Music must be an AAC .m4a or MP4 file for this test.');musicSink=new AudioMixer(a,0,10);}
  const total=Math.ceil((end-start)*FPS),duration=end-start;
  const canvas=new OffscreenCanvas(W,H),ctx=canvas.getContext('2d')!;
  output=new Output({format:new Mp4OutputFormat({fastStart:false}),target:new BufferTarget()});
  const vs=new CanvasSource(canvas,{codec:'avc',bitrate:2000000});
  const as=new AudioSampleSource({codec:'aac',bitrate:128000});output.addVideoTrack(vs,{frameRate:FPS});output.addAudioTrack(as);await output.start();
  const sink=new VideoSampleSink(clip.v),original=clip.a?new AudioMixer(clip.a,start,end):null;
  const times=Array.from({length:total},(_,n)=>Math.min(start+n/FPS,end-0.000001));
  let frame=0,audioPosition=0;
  for await(const sample of sink.samplesAtTimestamps(times)){
   try{check();ctx.fillStyle='#000';ctx.fillRect(0,0,W,H);if(sample)sample.drawWithFit(ctx,{fit:'contain'});}finally{sample?.close();}
   if(caption){ctx.font='600 42px sans-serif';ctx.textAlign='center';const text=String(caption).slice(0,48);let size=42;while(ctx.measureText(text).width>W-72&&size>16){ctx.font=`600 ${--size}px sans-serif`;}
    ctx.fillStyle='rgba(0,0,0,.72)';ctx.fillRect(24,H-216,W-48,80);ctx.fillStyle='#fff';ctx.fillText(text,W/2,H-164);}
   await vs.add(frame/FPS,Math.min(1/FPS,duration-frame/FPS));frame++;
   const upTo=Math.min(Math.round(duration*SR),Math.round(frame/FPS*SR));
   // Interleave tracks so neither the muxer nor encoders accumulate a full project.
   while(audioPosition<upTo){check();const n=Math.min(12000,upTo-audioPosition);let b=[new Float32Array(n),new Float32Array(n)];
    await original?.fill(start+audioPosition/SR,n,volume,b);
    if(musicSink)await musicSink.fill(audioPosition/SR,n,0.25,b);
    else {for(let ch=0;ch<2;ch++){const d=b[ch];for(let k=0;k<n;k++){const t=(audioPosition+k)/SR;d[k]+=0.035*Math.sin(2*Math.PI*220*t);}}}
    for(let ch=0;ch<2;ch++){let d=b[ch];for(let k=0;k<n;k++)d[k]=Math.max(-0.95,Math.min(0.95,d[k]));}
    let data=new Float32Array(n*2);data.set(b[0]);data.set(b[1],n);let audio=new AudioSample({data,format:'f32-planar',numberOfChannels:2,sampleRate:SR,timestamp:audioPosition/SR});try{await as.add(audio);}finally{audio.close();}audioPosition+=n;
   }
   if(frame%3===0)self.postMessage({type:'progress',progress:frame/total});
  }
  check();vs.close();as.close();await output.finalize();check();
  const buffer=output.target.buffer;self.postMessage({type:'done',buffer,duration,aac:c.aac},[buffer]);
 }catch(err){try{await output?.cancel();}catch{}self.postMessage({type:'error',message:(err as Error).message});}
 finally{for(const m of mixers)await m.close();mixers=[];for(const i of inputs)i.dispose();inputs=[];output=null;running=false;}
};
