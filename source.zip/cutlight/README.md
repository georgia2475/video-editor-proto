# Cutlight Phase 0
Phone-first export feasibility test only. No Replica repository scripts were run or included. No private user data is packaged.

## Build
Install Node.js. Run `npm ci --ignore-scripts` and `npm run build`. Serve dist via HTTPS (or localhost). Vite uses a relative base path for GitHub Pages project URLs. No backend, API keys or telemetry.

## Scope
One H.264 SDR MP4, AAC audio or silent, up to 30s / 1080p / 50 MiB, exported cut up to 10s at 720x1280/30fps, one burned-in caption. Optional AAC M4A/MP4 music at 25%, otherwise a quiet test tone. Local media only. Foreground worker export, bounded frames and chunked audio. Output encoded bytes are buffered with a 10-second/2 Mbps limit. Restore project manifest then relink source media.

## Licensing and replacements
Original app source is MIT licensed (see LICENSE). Bundled mediabunny and AAC wrapper source have their own MPL 2.0 notices. AAC fallback includes LGPL 2.1+ FFmpeg. Preserve all notices and source access. AAC package README contains its exact provenance, bridge source, Emscripten build and replacement instructions. To replace AAC, rebuild that upstream package, replace the dependency, then run this app's build. Nothing prevents modifying/relinking the app to use a modified AAC extension. Browser encoding/codec patents are separate.

## Phone test not completed here
Automated desktop Chromium export is not evidence of Android support. User should open the HTTPS site in Chrome, use test clip, enter caption, export, save MP4, play it in Gallery with sound. Then repeat with a short phone recording. Screen lock and app switching deliberately cancel export.
